% Hungarian hyphenation patterns with non-standard hyphenation patch
% ------------------------------------------------------------------
% Patch version: 2024-03-21
%
% Language: Hungarian (hu HU)
% Origin:   http://www.github.hu/bencenagy/huhyphn
% License:  MPL/GPL/LGPL license, 2011
% Author:   Nagy Bence <nagybence (at) tipogral (dot) hu>
% Version:  v20110815
% Patch:    László Németh <nemeth (at) numbertext (dot) org>
%           source: http://sourceforge.net/project/magyarispell (OOo huhyphn)
%           license: MPL/GPL/LGPL
