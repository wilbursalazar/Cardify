Hyphenation dictionary
-----------------------

Dictionary is created by converting TeX hyphenation patterns for Slovak
(Author: Jana Chlebíková) with lingucomponent-tools
(http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/oo-cs/lingucomponent-tools/).
